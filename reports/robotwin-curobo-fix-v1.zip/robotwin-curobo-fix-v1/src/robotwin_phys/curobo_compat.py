"""Guarded mask ownership repair for the pinned CuRobo v0.7.8 planners."""
import ast
import copy
import hashlib
import importlib
import inspect
import json
import subprocess
import textwrap
from pathlib import Path

from .conditions import ROOT

PIN = 'd64c4b005459db10c5dd867d8b30a87d5bda9bdb'
SOURCE_SHA256 = '348ee2fa858b1d651a70fa2b2b5a5d4e240ea724b7817d7769473c3f7a7e46e8'
FIX = 'independent-ik-result-masks-v1'
METHOD_HASHES = {
    '_plan_from_solve_state': 'f6dd2027b9c917f08c77f75f0858500b2bad53eb69abc7943255cd2764cc2f5e',
    '_plan_from_solve_state_batch': '68e958e0fcd5a59fe11c7233df0627df4cb8955b82d53a69be1864e1db42da19',
}


def method_checksum(node):
    canonical = copy.deepcopy(node)
    if (canonical.body and isinstance(canonical.body[0], ast.Expr) and
            isinstance(canonical.body[0].value, ast.Constant) and
            isinstance(canonical.body[0].value.value, str)):
        canonical.body = canonical.body[1:]

    def value(item):
        if isinstance(item, ast.AST):
            # Python 3.12 added type_params; the simulator uses Python 3.10.
            return {'type': type(item).__name__, 'fields': {
                key: value(child) for key, child in ast.iter_fields(item) if key != 'type_params'}}
        if isinstance(item, list):
            return [value(child) for child in item]
        return item

    return hashlib.sha256(json.dumps(value(canonical), sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def compatibility_metadata():
    repo = ROOT / 'vendor/curobo'
    revision = subprocess.check_output(['git', '-c', f'safe.directory={repo}', '-C', str(repo),
                                        'rev-parse', 'HEAD'], text=True).strip()
    path = repo / 'src/curobo/wrap/reacher/motion_gen.py'
    checksum = hashlib.sha256(path.read_bytes()).hexdigest()
    if revision != PIN or checksum != SOURCE_SHA256:
        raise RuntimeError('CuRobo revision/source differs from the reviewed v0.7.8; do not apply this repair')
    return {'revision': revision, 'motion_gen_sha256': checksum, 'compatibility_fix': FIX}


def repaired_function(function, name):
    source, first_line = inspect.getsourcelines(function)
    node = ast.parse(textwrap.dedent(''.join(source))).body[0]
    checksum = method_checksum(node)
    if checksum != METHOD_HASHES[name]:
        raise RuntimeError(f'Unreviewed CuRobo method: {name}')
    constructors = [n for n in ast.walk(node) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name)
                    and n.func.id == 'MotionGenResult']
    if len(constructors) != 1:
        raise RuntimeError('Expected one CuRobo result constructor')
    call = constructors[0]
    # IK remains unchanged when graph/trajopt failure marks result.success false.
    call.args[0] = ast.Call(func=ast.Attribute(value=call.args[0], attr='clone', ctx=ast.Load()),
                           args=[], keywords=[])
    ast.increment_lineno(node, first_line - 1)
    module = ast.Module(body=[ast.ImportFrom(module='__future__', names=[ast.alias(name='annotations')], level=0), node],
                        type_ignores=[])
    scope = dict(function.__globals__)
    exec(compile(ast.fix_missing_locations(module), function.__code__.co_filename, 'exec'), scope)
    replacement = scope[name]
    if replacement.__code__.co_freevars != function.__code__.co_freevars:
        raise RuntimeError('CuRobo repair would change method closure')
    return replacement


def install():
    compatibility_metadata()
    module = importlib.import_module('curobo.wrap.reacher.motion_gen')
    expected = (ROOT / 'vendor/curobo/src/curobo/wrap/reacher/motion_gen.py').resolve()
    if Path(module.__file__).resolve() != expected:
        raise RuntimeError('Imported CuRobo source is outside the reviewed repository')
    pending = []
    for name in METHOD_HASHES:
        function = getattr(module.MotionGen, name)
        if getattr(function, '_robotwin_mask_fix', None) == FIX:
            continue
        pending.append((function, repaired_function(function, name)))
    for function, replacement in pending:
        # Keep the original descriptor, defaults, globals and API identity.
        function.__code__ = replacement.__code__
        function._robotwin_mask_fix = FIX
