"""Recognize an exhausted official grasp search without hiding runtime errors."""
import numpy as np


class ExpertPlanningFailure(RuntimeError):
    """A valid grasp search completed but produced no reachable candidate."""

    def __init__(self, actor, arm_tag, contact_point_ids):
        self.diagnostics = {"kind": "no_reachable_grasp", "actor": actor.get_name(),
                            "arm": str(arm_tag), "contact_point_ids": np.asarray(contact_point_ids).tolist()}
        pose = actor.get_pose()
        self.diagnostics["actor_pose"] = {"p": np.asarray(pose.p).tolist(),
                                          "q": np.asarray(pose.q).tolist()}
        super().__init__(f"No reachable grasp for {self.diagnostics['actor']} "
                         f"with {arm_tag} arm after checking contacts {contact_point_ids}")


class PlanningMixin:
    @staticmethod
    def _validate_grasp_contact(actor, index):
        matrix = actor.get_contact_point(index, "matrix")
        if matrix is None:
            raise ValueError(f"Missing grasp contact point {index} for {actor.get_name()}")
        matrix = np.asarray(matrix)
        if matrix.shape != (4, 4) or not np.isfinite(matrix).all():
            raise ValueError(f"Invalid grasp contact point {index} for {actor.get_name()}")

    def get_grasp_pose(self, actor, arm_tag, contact_point_id=0, pre_dis=0.0):
        if self.plan_success:
            self._validate_grasp_contact(actor, contact_point_id)
        pose = super().get_grasp_pose(actor, arm_tag, contact_point_id, pre_dis)
        # Some official tasks query one contact directly. During a multi-contact
        # search, None must remain available so the next contact can be tried.
        if pose is None and not getattr(self, "_grasp_search_depth", 0):
            self.plan_success = False
            raise ExpertPlanningFailure(actor, arm_tag, [contact_point_id])
        return pose

    def choose_grasp_pose(self, actor, arm_tag, pre_dis=0.1, target_dis=0,
                          contact_point_id=None):
        # Preserve upstream's short circuit after an earlier failed action.
        if not self.plan_success:
            return super().choose_grasp_pose(actor, arm_tag, pre_dis, target_dis, contact_point_id)
        if contact_point_id is None:
            contacts = [i for i, _ in actor.iter_contact_points()]
        else:
            contacts = contact_point_id if isinstance(contact_point_id, list) else [contact_point_id]
        if not contacts:
            raise ValueError(f"Missing grasp contact points for {actor.get_name()}")
        # Official Actor.get_point can silently return None for missing metadata.
        # Only classify an exhausted search as infeasible when its inputs exist.
        for index in contacts:
            self._validate_grasp_contact(actor, index)
        # Keep the official search and its candidate selection unchanged.
        depth = getattr(self, "_grasp_search_depth", 0)
        self._grasp_search_depth = depth + 1
        try:
            result = super().choose_grasp_pose(actor, arm_tag, pre_dis, target_dis, contact_point_id)
        finally:
            self._grasp_search_depth = depth
        if result[0] is None and result[1] is None:
            self.plan_success = False
            raise ExpertPlanningFailure(actor, arm_tag, contacts)
        if result[0] is None or result[1] is None:
            raise RuntimeError("Grasp search returned an incomplete pose pair")
        return result
